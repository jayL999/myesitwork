function msg ( ) {
alert("Hello jay lekhani form sem 1");
}